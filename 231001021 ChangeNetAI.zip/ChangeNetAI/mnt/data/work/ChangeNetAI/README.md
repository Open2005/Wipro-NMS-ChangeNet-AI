# ChangeNet AI

A beginner-friendly network monitoring dashboard for academic demonstration.

## Added analysis features
- Change Risk Indicator
- Device Health Timeline
- Device Comparison
- Monitoring Report
- Existing Device Stability Score and Smart Change Insight

## Run
Open `index.html` in a browser. The current demonstration version uses the built-in sample monitoring interface and does not require a database.
