const http = require('http');
const port = Number(process.env.PORT || 8000);
const server = http.createServer((req,res)=>{
  if(req.url === '/api/health'){
    res.writeHead(200, {'Content-Type':'application/json'});
    return res.end(JSON.stringify({status:'ok', project:'ChangeNet AI'}));
  }
  res.writeHead(404, {'Content-Type':'application/json'});
  res.end(JSON.stringify({error:'Not found'}));
});
server.listen(port,'127.0.0.1',()=>console.log(`ChangeNet AI backend running at http://127.0.0.1:${port}`));
server.on('error',err=>{console.error(`Could not start backend on port ${port}: ${err.message}`);process.exitCode=1;});
